package Day02;

public class Ex01_ArithmethicOperator {

	public static void main(String[] args) {
		// 산술 연산자
		System.out.println(10 + 5);
		System.out.println(8 - 3);
		System.out.println(5 * 4);
		System.out.println(16 / 2);
		System.out.println(10 % 6);
		System.out.println(1 % 3);		//1
		System.out.println(2 % 3);		//2
		System.out.println(3 % 3);		//0
		System.out.println();	
	}
	
	
}
