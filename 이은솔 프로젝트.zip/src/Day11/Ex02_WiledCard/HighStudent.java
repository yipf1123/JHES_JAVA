package Day11.Ex02_WiledCard;

public class HighStudent extends Student {

	public HighStudent(String name) {
		super(name);
	}

}
