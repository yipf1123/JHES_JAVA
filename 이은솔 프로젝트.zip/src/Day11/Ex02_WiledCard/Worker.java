package Day11.Ex02_WiledCard;

public class Worker extends Person {

	public Worker(String name) {
		super(name);

	}

}
